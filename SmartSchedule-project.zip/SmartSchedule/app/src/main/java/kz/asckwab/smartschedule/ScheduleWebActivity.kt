package kz.asckwab.smartschedule

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class ScheduleWebActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private var checks = 0
    private var syncSucceeded = false
    private var currentPageToken = 0

    private val retryRunnable = object : Runnable {
        override fun run() {
            if (syncSucceeded || isFinishing || !::webView.isInitialized) return
            checks++
            inspectPage()
            if (!syncSucceeded && checks < 24) handler.postDelayed(this, 500L)
            else if (!syncSucceeded) {
                status.text = "Если ты уже вошёл, открой меню → «Процесс обучения» → «Расписание». Когда таблица появится, нажми «Проверить и сохранить»."
                progress.visibility = ProgressBar.GONE
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(245, 247, 251)
        window.navigationBarColor = Color.rgb(245, 247, 251)
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        buildUi()
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                status.text = "Страница загружается… После входа открой расписание."
                progress.visibility = ProgressBar.VISIBLE
                currentPageToken++
                handler.removeCallbacks(retryRunnable)
                checks = 0
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progress.visibility = ProgressBar.GONE
                handler.removeCallbacks(retryRunnable)
                checks = 0
                handler.postDelayed(retryRunnable, 400L)
            }
        }
        webView.loadUrl(SCHEDULE_URL)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    @Suppress("SetJavaScriptEnabled")
    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 247, 251))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(10))
            setBackgroundColor(Color.WHITE)
        }
        val title = TextView(this).apply {
            text = "Подключение к SmartNation"
            textSize = 18f
            setTextColor(Color.rgb(24, 35, 54))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        top.addView(title)
        status = TextView(this).apply {
            text = "Войди в аккаунт. Приложение не отправляет логин и пароль куда-либо ещё."
            textSize = 12f
            setTextColor(Color.rgb(103, 115, 136))
            setPadding(0, dp(5), 0, dp(8))
        }
        top.addView(status)
        val action = Button(this).apply {
            text = "Проверить и сохранить расписание"
            isAllCaps = false
            setOnClickListener {
                checks = 0
                handler.removeCallbacks(retryRunnable)
                status.text = "Проверяю, появилась ли таблица расписания…"
                progress.visibility = ProgressBar.VISIBLE
                inspectPage()
                if (!syncSucceeded) handler.postDelayed(retryRunnable, 500L)
            }
        }
        top.addView(action, LinearLayout.LayoutParams(-1, dp(46)))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = ProgressBar.GONE
        }
        top.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))
        root.addView(top, LinearLayout.LayoutParams(-1, -2))
        webView = WebView(this)
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun inspectPage() {
        if (!::webView.isInitialized || syncSucceeded) return
        val token = currentPageToken
        webView.evaluateJavascript(EXTRACT_SCHEDULE_JS) { value ->
            if (syncSucceeded || isFinishing || token != currentPageToken || value == null || value == "null") return@evaluateJavascript
            val decoded = try {
                JSONArray("[$value]").getString(0)
            } catch (_: Exception) {
                value
            }
            val result = try { JSONObject(decoded) } catch (_: Exception) { null }
            if (result?.optBoolean("ok", false) == true) {
                val accepted = ScheduleStorage.saveFromWebJson(this, decoded)
                if (accepted) {
                    syncSucceeded = true
                    handler.removeCallbacks(retryRunnable)
                    progress.visibility = ProgressBar.GONE
                    status.text = "Расписание сохранено. Возвращаюсь в приложение…"
                    Toast.makeText(this, "Расписание сохранено", Toast.LENGTH_SHORT).show()
                    handler.postDelayed({ if (!isFinishing) finish() }, 800L)
                } else {
                    status.text = "Таблица найдена, но данные не удалось сохранить. Попробуй ещё раз."
                }
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val SCHEDULE_URL = "https://college.smartnation.kz/ru/atr/control/training-schedule/33125"

        // The page's own rendered table is read only after the user signs in through WebView.
        // The app does not copy or upload credentials, cookies, raw HTML, or CSRF tokens. WebView may keep its own local sign-in session.
        private val EXTRACT_SCHEDULE_JS = """
            (function() {
              if (location.hostname !== 'college.smartnation.kz') return JSON.stringify({ok:false, reason:'not-smartnation-host'});
              const clean = v => (v || '').replace(/\s+/g, ' ').trim();
              const table = document.querySelector('table.s-table-schedule');
              if (!table) return JSON.stringify({ok:false, reason:'table-not-found'});
              const headerCells = Array.from(table.rows[0] ? table.rows[0].cells : []).slice(1);
              const days = headerCells.map(cell => {
                const text = clean(cell.innerText || cell.textContent);
                const m = text.match(/(Понедельник|Вторник|Среда|Четверг|Пятница|Суббота|Воскресенье)\s+(\d{2}\.\d{2}\.\d{4})/i);
                if (!m) return null;
                const p = m[2].split('.');
                return {weekday:m[1], date:p[2] + '-' + p[1] + '-' + p[0], lessons:[]};
              });
              const rows = Array.from(table.rows).slice(1);
              const labelValue = (card, wanted) => {
                const labels = Array.from(card.querySelectorAll('.s-table-schedule__card-label'));
                for (const label of labels) {
                  if (clean(label.innerText).toLowerCase() === wanted.toLowerCase()) {
                    let sibling = label.nextElementSibling;
                    while (sibling && !sibling.classList.contains('s-table-schedule__card-desc')) sibling = sibling.nextElementSibling;
                    return sibling ? clean(sibling.innerText) : '';
                  }
                }
                return '';
              };
              rows.forEach(row => {
                const cells = Array.from(row.cells);
                if (cells.length < 2) return;
                const times = clean(cells[0].innerText).match(/\d{2}:\d{2}/g) || [];
                const start = times[0] || '';
                const end = times[1] || '';
                days.forEach((day, dayIndex) => {
                  if (!day) return;
                  const cell = cells[dayIndex + 1];
                  if (!cell) return;
                  Array.from(cell.querySelectorAll('.s-table-schedule__card')).forEach(card => {
                    const room = clean(card.querySelector('.s-table-schedule__card-tag-blue')?.innerText);
                    const subject = clean(card.querySelector('.s-table-schedule__card-tag-green')?.innerText);
                    const descriptions = Array.from(card.querySelectorAll('.s-table-schedule__card-desc')).map(e => clean(e.innerText)).filter(Boolean);
                    const type = descriptions.find(v => /практик|лекци|семинар|сроп|лаборатор|экзамен|зач[её]т|консультац/i.test(v)) || '';
                    const teacher = labelValue(card, 'Преподаватели');
                    const subgroup = labelValue(card, 'Подгруппа');
                    if (subject || room) day.lessons.push({start:start, end:end, room:room, subject:subject || 'Занятие', teacher:teacher, type:type, subgroup:subgroup});
                  });
                });
              });
              return JSON.stringify({ok:true, days:days.filter(Boolean)});
            })();
        """.trimIndent()
    }
}
