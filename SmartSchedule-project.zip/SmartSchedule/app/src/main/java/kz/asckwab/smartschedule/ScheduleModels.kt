package kz.asckwab.smartschedule

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class Lesson(
    val start: String,
    val end: String,
    val room: String,
    val subject: String,
    val teacher: String,
    val type: String,
    val subgroup: String
)

data class ScheduleDay(
    val date: String,
    val weekday: String,
    val lessons: List<Lesson>
)

data class SavedSchedule(
    val fetchedAt: Long,
    val days: List<ScheduleDay>
)

object ScheduleStorage {
    private const val PREFS = "smart_schedule_data"
    private const val KEY_JSON = "schedule_json"
    private const val KEY_SYNCED_AT = "synced_at"

    fun load(context: Context): SavedSchedule? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_JSON, null) ?: return null
        return try {
            val root = JSONObject(raw)
            val days = parseDays(root.optJSONArray("days") ?: JSONArray())
            if (days.isEmpty()) null else SavedSchedule(
                fetchedAt = prefs.getLong(KEY_SYNCED_AT, 0L),
                days = days
            )
        } catch (_: Exception) {
            null
        }
    }

    fun saveFromWebJson(context: Context, raw: String): Boolean {
        return try {
            val root = JSONObject(raw)
            if (!root.optBoolean("ok", false)) return false
            val days = parseDays(root.optJSONArray("days") ?: JSONArray())
            if (days.isEmpty()) return false

            // Store only the extracted timetable fields, not the HTML page, cookies, or login details.
            val clean = JSONObject().put("ok", true).put("days", daysToJson(days)).toString()
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_JSON, clean)
                .putLong(KEY_SYNCED_AT, System.currentTimeMillis())
                .apply()
            ScheduleWidgetProvider.updateAll(context)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun lastSyncLabel(context: Context): String {
        val time = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(KEY_SYNCED_AT, 0L)
        if (time == 0L) return "Ещё не синхронизировано"
        val formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy, HH:mm", Locale("ru"))
        return "Обновлено: " + java.time.Instant.ofEpochMilli(time)
            .atZone(java.time.ZoneId.systemDefault()).format(formatter)
    }

    private fun parseDays(array: JSONArray): List<ScheduleDay> {
        val result = mutableListOf<ScheduleDay>()
        for (i in 0 until array.length()) {
            val dayObj = array.optJSONObject(i) ?: continue
            val date = dayObj.optString("date")
            if (date.isBlank()) continue
            val lessonsArray = dayObj.optJSONArray("lessons") ?: JSONArray()
            val lessons = mutableListOf<Lesson>()
            for (j in 0 until lessonsArray.length()) {
                val obj = lessonsArray.optJSONObject(j) ?: continue
                val subject = obj.optString("subject").trim()
                val room = obj.optString("room").trim()
                if (subject.isBlank() && room.isBlank()) continue
                lessons += Lesson(
                    start = obj.optString("start"),
                    end = obj.optString("end"),
                    room = room,
                    subject = subject.ifBlank { "Занятие" },
                    teacher = obj.optString("teacher"),
                    type = obj.optString("type"),
                    subgroup = obj.optString("subgroup")
                )
            }
            result += ScheduleDay(date, dayObj.optString("weekday"), lessons.sortedBy { ScheduleLogic.timeMinutes(it.start) })
        }
        return result.sortedBy { it.date }
    }

    private fun daysToJson(days: List<ScheduleDay>): JSONArray {
        val arr = JSONArray()
        days.forEach { day ->
            val lessonArr = JSONArray()
            day.lessons.forEach { lesson ->
                lessonArr.put(JSONObject()
                    .put("start", lesson.start)
                    .put("end", lesson.end)
                    .put("room", lesson.room)
                    .put("subject", lesson.subject)
                    .put("teacher", lesson.teacher)
                    .put("type", lesson.type)
                    .put("subgroup", lesson.subgroup))
            }
            arr.put(JSONObject().put("date", day.date).put("weekday", day.weekday).put("lessons", lessonArr))
        }
        return arr
    }
}

object ScheduleLogic {
    private val dateFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale("ru"))
    private val shortWeekdays = mapOf(
        "Понедельник" to "Пн", "Вторник" to "Вт", "Среда" to "Ср",
        "Четверг" to "Чт", "Пятница" to "Пт", "Суббота" to "Сб", "Воскресенье" to "Вс"
    )

    fun selectDay(days: List<ScheduleDay>, now: LocalDateTime = LocalDateTime.now()): ScheduleDay? {
        val today = now.toLocalDate().toString()
        val todayEntry = days.firstOrNull { it.date == today }
        if (todayEntry != null && todayEntry.lessons.isNotEmpty()) {
            val lastEnd = todayEntry.lessons.mapNotNull { parseTime(it.end) }.maxOrNull()
            if (lastEnd == null || now.toLocalTime().isBefore(lastEnd)) return todayEntry
        }
        return days.asSequence()
            .filter { it.date > today && it.lessons.isNotEmpty() }
            .minByOrNull { it.date }
    }

    fun dateLabel(day: ScheduleDay): String {
        val date = try {
            LocalDate.parse(day.date).format(dateFormatter)
        } catch (_: Exception) {
            day.date
        }
        return "${shortWeekdays[day.weekday] ?: day.weekday} · $date"
    }

    fun timeMinutes(value: String): Int = parseTime(value)?.let { it.hour * 60 + it.minute } ?: Int.MAX_VALUE

    private fun parseTime(value: String): LocalTime? = try {
        LocalTime.parse(value.trim(), DateTimeFormatter.ofPattern("H:mm"))
    } catch (_: Exception) {
        try { LocalTime.parse(value.trim(), DateTimeFormatter.ofPattern("HH:mm")) } catch (_: Exception) { null }
    }
}
