package kz.asckwab.smartschedule

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class ScheduleWidgetRefreshWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : Worker(appContext, workerParams) {
    override fun doWork(): Result {
        ScheduleWidgetProvider.updateAll(applicationContext)
        return Result.success()
    }
}
