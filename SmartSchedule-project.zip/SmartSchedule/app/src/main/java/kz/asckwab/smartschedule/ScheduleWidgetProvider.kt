package kz.asckwab.smartschedule

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.time.LocalDate

class ScheduleWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { updateOne(context, manager, it) }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, ScheduleWidgetProvider::class.java)
            manager.getAppWidgetIds(component).forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_schedule)
            val openIntent = Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(
                context,
                2000 + id,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pending)

            val saved = ScheduleStorage.load(context)
            val selected = saved?.let { ScheduleLogic.selectDay(it.days) }
            if (selected == null) {
                views.setTextViewText(R.id.widget_title, "Моё расписание")
                views.setTextViewText(R.id.widget_date, "Нет актуальных данных")
                views.setTextViewText(R.id.widget_lessons, "Нажми, чтобы открыть приложение и синхронизировать SmartNation.")
            } else {
                val today = LocalDate.now().toString()
                views.setTextViewText(
                    R.id.widget_title,
                    if (selected.date == today) "Сегодняшние пары" else "Следующий учебный день"
                )
                views.setTextViewText(R.id.widget_date, ScheduleLogic.dateLabel(selected))
                val body = if (selected.lessons.isEmpty()) {
                    "Занятий нет"
                } else {
                    selected.lessons.take(5).joinToString("\n") { lesson ->
                        val time = if (lesson.start.isNotBlank()) lesson.start else "—:—"
                        val room = lesson.room.takeIf { it.isNotBlank() }?.let { " · $it" } ?: ""
                        "$time  $room  ${lesson.subject}".replace(Regex(" {2,}"), " ").trim()
                    } + if (selected.lessons.size > 5) "\nЕщё ${selected.lessons.size - 5}…" else ""
                }
                views.setTextViewText(R.id.widget_lessons, body)
            }
            manager.updateAppWidget(id, views)
        }
    }
}
