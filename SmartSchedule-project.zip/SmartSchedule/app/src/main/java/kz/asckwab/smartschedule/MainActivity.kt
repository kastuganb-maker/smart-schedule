package kz.asckwab.smartschedule

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var dayPicker: Spinner
    private lateinit var lessonContainer: LinearLayout
    private var saved: SavedSchedule? = null
    private var pickerReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(245, 247, 251)
        window.navigationBarColor = Color.rgb(245, 247, 251)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        scheduleWidgetRefresh()
        createView()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) renderSchedule()
    }

    private fun scheduleWidgetRefresh() {
        val request = PeriodicWorkRequestBuilder<ScheduleWidgetRefreshWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "smart_schedule_widget_refresh", ExistingPeriodicWorkPolicy.UPDATE, request
        )
    }

    private fun createView() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(245, 247, 251))
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderSchedule()
    }

    private fun renderSchedule() {
        if (!::content.isInitialized) return
        saved = ScheduleStorage.load(this)
        content.removeAllViews()
        pickerReady = false

        addText(content, "SMART РАСПИСАНИЕ", 12, Color.rgb(52, 84, 209), true, top = 0)
        addText(content, "Мои пары", 30, Color.rgb(24, 35, 54), true, top = 5)
        addText(content, "Расписание из личного кабинета SmartNation", 14, Color.rgb(103, 115, 136), false, top = 4)

        val syncButton = Button(this).apply {
            text = "Открыть SmartNation / обновить"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(52, 84, 209), 14)
            setOnClickListener { startActivity(Intent(this@MainActivity, ScheduleWebActivity::class.java)) }
        }
        val buttonParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(20) }
        content.addView(syncButton, buttonParams)

        status = addText(content, ScheduleStorage.lastSyncLabel(this), 12, Color.rgb(103, 115, 136), false, top = 8)

        val schedule = saved
        if (schedule == null || schedule.days.isEmpty()) {
            val blank = card()
            addText(blank, "Пока нет сохранённого расписания", 18, Color.rgb(24, 35, 54), true, top = 0)
            addText(blank, "Нажми кнопку выше, войди в SmartNation и открой «Процесс обучения → Расписание». Когда таблица появится, приложение сохранит её.", 14, Color.rgb(77, 90, 112), false, top = 8)
            content.addView(blank, matchWrap(top = 18))
            return
        }

        val automatic = ScheduleLogic.selectDay(schedule.days)
        val initial = automatic ?: schedule.days.last()
        addText(content, "Выбрать день", 14, Color.rgb(65, 76, 96), true, top = 18)
        dayPicker = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_item,
                schedule.days.map { ScheduleLogic.dateLabel(it) }
            ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (pickerReady && position in schedule.days.indices) {
                        renderLessons(schedule.days[position], automatic?.date == schedule.days[position].date)
                    }
                }
            }
        }
        content.addView(dayPicker, matchWrap(top = 3))
        lessonContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(lessonContainer, matchWrap(top = 0))
        val selectedIndex = schedule.days.indexOfFirst { it.date == initial.date }.coerceAtLeast(0)
        dayPicker.setSelection(selectedIndex, false)
        pickerReady = true
        renderLessons(initial, automatic?.date == initial.date)
    }

    private fun renderLessons(day: ScheduleDay, isAutomatic: Boolean) {
        // Rebuild only the lessons area; the day selector remains in place.
        if (!::lessonContainer.isInitialized) return
        lessonContainer.removeAllViews()
        if (saved?.let { ScheduleLogic.selectDay(it.days) } == null) {
            val notice = TextView(this).apply {
                text = "В сохранённой неделе больше нет будущих занятий. Нажми «Открыть SmartNation / обновить», чтобы получить новую неделю."
                textSize = 13f
                setTextColor(Color.rgb(133, 88, 17))
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(Color.rgb(255, 244, 214), 12)
            }
            lessonContainer.addView(notice, matchWrap(top = 10))
        }
        val today = java.time.LocalDate.now().toString()
        val bannerText = when {
            day.date == today -> "Расписание на сегодня"
            isAutomatic -> "Ближайший учебный день"
            else -> "Выбранный день"
        }
        addText(lessonContainer, bannerText, 13, Color.rgb(52, 84, 209), true, top = 18)
        if (day.lessons.isEmpty()) {
            val empty = card()
            addText(empty, "Пар нет", 18, Color.rgb(24, 35, 54), true, top = 0)
            addText(empty, "На этот день в сохранённой таблице занятий нет.", 14, Color.rgb(103, 115, 136), false, top = 6)
            lessonContainer.addView(empty, matchWrap(top = 10))
            return
        }
        day.lessons.forEachIndexed { index, lesson ->
            val lessonCard = card()
            val time = if (lesson.start.isNotBlank() && lesson.end.isNotBlank()) "${lesson.start}–${lesson.end}" else "Время не указано"
            addText(lessonCard, time, 13, Color.rgb(52, 84, 209), true, top = 0)
            addText(lessonCard, lesson.subject, 17, Color.rgb(24, 35, 54), true, top = 5)
            if (lesson.room.isNotBlank()) addText(lessonCard, "Кабинет: ${lesson.room}", 14, Color.rgb(40, 51, 71), false, top = 6)
            if (lesson.type.isNotBlank()) addText(lessonCard, lesson.type, 13, Color.rgb(103, 115, 136), false, top = 5)
            if (lesson.teacher.isNotBlank()) addText(lessonCard, lesson.teacher, 13, Color.rgb(103, 115, 136), false, top = 4)
            if (lesson.subgroup.isNotBlank()) addText(lessonCard, "Подгруппа: ${lesson.subgroup}", 12, Color.rgb(103, 115, 136), false, top = 4)
            lessonContainer.addView(lessonCard, matchWrap(top = if (index == 0) 8 else 10))
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = rounded(Color.WHITE, 16)
        elevation = dp(1).toFloat()
    }

    private fun addText(
        parent: LinearLayout,
        text: String,
        size: Int,
        color: Int,
        bold: Boolean,
        top: Int
    ): TextView {
        val view = TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.START
            includeFontPadding = true
        }
        parent.addView(view, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
        return view
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun matchWrap(top: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
